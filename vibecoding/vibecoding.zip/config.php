<?php
/**
 * Telegram Notification Configuration
 * Version: 1.0
 * Date: 2024-12-29
 * 
 * INSTRUCTIONS:
 * 1. Get bot token from @BotFather on Telegram
 * 2. Get your chat ID from @userinfobot on Telegram
 * 3. Fill in the values below
 * 4. Save this file
 */

// ============================================================================
// TELEGRAM CONFIGURATION
// ============================================================================

/**
 * Telegram Bot Token
 * 
 * How to get:
 * 1. Open Telegram and search for @BotFather
 * 2. Send: /newbot
 * 3. Follow instructions to create bot
 * 4. Copy the token (format: 123456789:ABC...)
 */
$TELEGRAM_BOT_TOKEN = 'YOUR_BOT_TOKEN_HERE';

/**
 * Telegram Chat ID
 * 
 * How to get:
 * 1. Open Telegram and search for @userinfobot
 * 2. Send: /start
 * 3. Bot will reply with your user ID
 * 4. Copy the ID (format: 123456789)
 */
$TELEGRAM_CHAT_ID = 'YOUR_CHAT_ID_HERE';

// ============================================================================
// ADVANCED CONFIGURATION (Optional)
// ============================================================================

/**
 * Timezone
 */
date_default_timezone_set('Asia/Tehran');

/**
 * Log retention (days)
 * Logs older than this will be automatically deleted
 */
$LOG_RETENTION_DAYS = 30;

/**
 * Max retries for failed messages
 */
$MAX_RETRIES = 3;

// ============================================================================
// VALIDATION
// ============================================================================

function validateConfig() {
    global $TELEGRAM_BOT_TOKEN, $TELEGRAM_CHAT_ID;
    
    $errors = [];
    
    if ($TELEGRAM_BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE' || empty($TELEGRAM_BOT_TOKEN)) {
        $errors[] = 'Bot token not configured. See comments in config.php';
    }
    
    if ($TELEGRAM_CHAT_ID === 'YOUR_CHAT_ID_HERE' || empty($TELEGRAM_CHAT_ID)) {
        $errors[] = 'Chat ID not configured. See comments in config.php';
    }
    
    if (!empty($errors)) {
        return [
            'valid' => false,
            'errors' => $errors
        ];
    }
    
    return ['valid' => true];
}

// Auto-validate on include (unless in setup mode)
if (!isset($_GET['setup'])) {
    $validation = validateConfig();
    if (!$validation['valid']) {
        http_response_code(500);
        die(json_encode([
            'success' => false,
            'error' => 'Configuration error',
            'details' => $validation['errors']
        ]));
    }
}
